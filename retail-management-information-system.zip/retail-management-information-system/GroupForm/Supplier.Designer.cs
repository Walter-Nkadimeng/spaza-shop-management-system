﻿namespace grp3PROJECT
{
    partial class Supplier
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dgvProducts = new System.Windows.Forms.DataGridView();
            this.label1 = new System.Windows.Forms.Label();
            this.btnView = new System.Windows.Forms.Button();
            this.btnMaintainSupplier = new System.Windows.Forms.Button();
            this.linklb = new System.Windows.Forms.LinkLabel();
            ((System.ComponentModel.ISupportInitialize)(this.dgvProducts)).BeginInit();
            this.SuspendLayout();
            // 
            // dgvProducts
            // 
            this.dgvProducts.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvProducts.Location = new System.Drawing.Point(13, 55);
            this.dgvProducts.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.dgvProducts.Name = "dgvProducts";
            this.dgvProducts.Size = new System.Drawing.Size(584, 375);
            this.dgvProducts.TabIndex = 7;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(78, 19);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(428, 24);
            this.label1.TabIndex = 6;
            this.label1.Text = "Welcome to Temba\'s spazashop Applicatioin";
            // 
            // btnView
            // 
            this.btnView.Location = new System.Drawing.Point(13, 436);
            this.btnView.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btnView.Name = "btnView";
            this.btnView.Size = new System.Drawing.Size(89, 47);
            this.btnView.TabIndex = 5;
            this.btnView.Text = "View All";
            this.btnView.UseVisualStyleBackColor = true;
            this.btnView.Click += new System.EventHandler(this.btnView_Click);
            // 
            // btnMaintainSupplier
            // 
            this.btnMaintainSupplier.Location = new System.Drawing.Point(441, 436);
            this.btnMaintainSupplier.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btnMaintainSupplier.Name = "btnMaintainSupplier";
            this.btnMaintainSupplier.Size = new System.Drawing.Size(89, 47);
            this.btnMaintainSupplier.TabIndex = 8;
            this.btnMaintainSupplier.Text = "Maintain Supplier details";
            this.btnMaintainSupplier.UseVisualStyleBackColor = true;
            this.btnMaintainSupplier.Click += new System.EventHandler(this.btnMaintainSupplier_Click);
            // 
            // linklb
            // 
            this.linklb.AutoSize = true;
            this.linklb.Location = new System.Drawing.Point(561, 464);
            this.linklb.Name = "linklb";
            this.linklb.Size = new System.Drawing.Size(31, 13);
            this.linklb.TabIndex = 9;
            this.linklb.TabStop = true;
            this.linklb.Text = "back";
            this.linklb.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linklb_LinkClicked);
            // 
            // Supplier
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(604, 487);
            this.Controls.Add(this.linklb);
            this.Controls.Add(this.btnMaintainSupplier);
            this.Controls.Add(this.dgvProducts);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnView);
            this.Name = "Supplier";
            this.Text = "Supplier";
            this.Load += new System.EventHandler(this.Supplier_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvProducts)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.DataGridView dgvProducts;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnView;
        private System.Windows.Forms.Button btnMaintainSupplier;
        private System.Windows.Forms.LinkLabel linklb;
    }
}