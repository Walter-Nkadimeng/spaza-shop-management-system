﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace grp3PROJECT
{
    public partial class Supplier : Form
    {
        //Declare and assign the field
        SqlCommand cmd;
        SqlDataAdapter adapter = new SqlDataAdapter();
        DataSet data = new DataSet();
        public Supplier()
        {
            InitializeComponent();
        }

        private void btnView_Click(object sender, EventArgs e)
        {
            try
            {
                using (SqlConnection conn = new SqlConnection(DBConfig.ConnectionString))
                {
                    conn.Open();

                    cmd = new SqlCommand("SELECT * FROM Supplier", conn);

                    adapter.SelectCommand = cmd;
                    adapter.Fill(data, "Supplier");

                    dgvProducts.DataSource = data;
                    dgvProducts.DataMember = "Supplier";

                    conn.Close();
                }
                
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnMaintainSupplier_Click(object sender, EventArgs e)
        {
            MaintainSupplier maintainSupplier = new MaintainSupplier();
            maintainSupplier.ShowDialog();
            this.Hide();
        }

        private void Supplier_Load(object sender, EventArgs e)
        {

        }

        private void linklb_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            btnMaintainSupp back = new btnMaintainSupp();
            back.ShowDialog();
            this.Hide();
        }
    }
}
