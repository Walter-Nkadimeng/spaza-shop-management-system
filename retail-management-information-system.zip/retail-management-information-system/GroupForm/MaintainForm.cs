﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace grp3PROJECT
{
    public partial class btnMaintainSupp : Form
    {
        SqlConnection conn;
        SqlCommand cmd;
        SqlDataAdapter adapt;
        DataSet ds;

        public btnMaintainSupp()
        {
            InitializeComponent();
        }

        private void btnDisplaySuppliers_Click(object sender, EventArgs e)
        {
            try
            {
                using (SqlConnection conn = new SqlConnection(DBConfig.ConnectionString))
                {
                    conn.Open();
                    string select = "SELECT Name FROM Supplier";
                    cmd = new SqlCommand(select, conn);
                    adapt = new SqlDataAdapter(cmd);
                    DataTable table = new DataTable();
                    adapt.Fill(table);
                    dataGridView1.DataSource = table;

                    dataGridView1.Refresh();
                    dataGridView1.AutoGenerateColumns = true;
                    conn.Close();
                }
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnDisplayProducts_Click(object sender, EventArgs e)
        {
            try
            {
                using (SqlConnection conn = new SqlConnection(DBConfig.ConnectionString))
                {
                    conn.Open();

                    string select = "SELECT * FROM [Order]";
                    SqlCommand cmd = new SqlCommand(select, conn);
                    SqlDataAdapter adapt = new SqlDataAdapter(cmd);

                    DataTable table = new DataTable();
                    adapt.Fill(table);

                    dataGridView1.AutoGenerateColumns = true;
                    dataGridView1.DataSource = table;
                }
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            ReportForm reportForm = new ReportForm();
            reportForm.ShowDialog();
            this.Hide();
        }

        private void MaintainForm_Load(object sender, EventArgs e)
        {

        }

        private void btnDisplayCustomer_Click(object sender, EventArgs e)
        {
            try
            {
                using (SqlConnection conn = new SqlConnection(DBConfig.ConnectionString))
                {
                    conn.Open();

                    string sql = @"SELECT FName, LName FROM [Customer]";
                    SqlDataAdapter adapt = new SqlDataAdapter(sql, conn);

                    DataTable table = new DataTable();
                    adapt.Fill(table);

                    dataGridView1.AutoGenerateColumns = true;
                    dataGridView1.DataSource = table;
                }
            }
            catch (SqlException error)
            {
                MessageBox.Show(error.Message);
            }
        }

        private void btnMaintainSupply_Click(object sender, EventArgs e)
        {
            Supplier supplier= new Supplier();
            supplier.ShowDialog();
            this.Hide();
        }

        private void linklb_back_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            loginForm login = new loginForm();
            login.Show();

            this.Hide();
        }
    }
}
