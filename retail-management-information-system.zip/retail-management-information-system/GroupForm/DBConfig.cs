﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace grp3PROJECT
{
    public static class DBConfig
    {
        // ✅ Central connection string for your project
        public static readonly string ConnectionString = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\mahla\Downloads\retail-management-information-system\GroupForm\Spaza_DB.mdf;Integrated Security=True;Connect Timeout=30";
    }
}
