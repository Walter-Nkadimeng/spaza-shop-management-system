﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace grp3PROJECT
{
    public partial class Order : Form
    {
        SqlConnection conn;
        SqlCommand cmd;
        SqlDataAdapter adapter;
        DataSet ds;
        public Order()
        {
            InitializeComponent();
        }

        private void Order_Load(object sender, EventArgs e)
        {
            // Populate menu items manually
            comboBox1.Items.Clear();

            comboBox1.Items.Add("Sandwich");
            comboBox1.Items.Add("Fries");
            comboBox1.Items.Add("Fish and Chips");
            comboBox1.Items.Add("Kota");
            comboBox1.Items.Add("Beef Burger");
            comboBox1.Items.Add("Cheese Burger");

            comboBox1.SelectedIndex = 0;

            MessageBox.Show("Menu loaded successfully");
        }

        private void btnChoice_Click_1(object sender, EventArgs e)
        {

            // Validate selections
            if (comboBox1.SelectedItem == null || cbQuant.SelectedItem == null)
            {
                MessageBox.Show("Please select an item and quantity.");
                return;
            }

            string customerID = loginForm.LoggedInCustomerID;
            string item = comboBox1.SelectedItem.ToString();
            int quantity = int.Parse(cbQuant.SelectedItem.ToString());

            int unitPrice = 0;

            // Set prices
            switch (item)
            {
                case "Sandwich": unitPrice = 15; break;
                case "Fries": unitPrice = 25; break;
                case "Fish and Chips": unitPrice = 40; break;
                case "Kota": unitPrice = 30; break;
                case "Beef Burger": unitPrice = 50; break;
                case "Cheese Burger": unitPrice = 45; break;
            }

            int totalPrice = unitPrice * quantity;

            // Display price on label
            lbPrice.Text = "R " + unitPrice.ToString();

            // Add header once
            if (OrderList.Items.Count == 0)
            {
                OrderList.Items.Add("");
                OrderList.Items.Add("------------------------------------------");
            }

            // Add order line
            OrderList.Items.Add(
                customerID + "|" +
                item + "|" +
                quantity + "|" +
                totalPrice
            );

        }
        private void btnRemove_Click(object sender, EventArgs e)
        {
            //Deleting selected values on the Orderlist
            if (OrderList.SelectedIndex != -1)
            {
                OrderList.Items.RemoveAt(OrderList.SelectedIndex);
            }
        }

        private void btnSubmitOrder_Click(object sender, EventArgs e)
        {

            if (OrderList.Items.Count == 0)
            {
                MessageBox.Show("No items to submit.");
                return;
            }

            using (SqlConnection conn = new SqlConnection(DBConfig.ConnectionString))
            {
                try
                {
                    conn.Open();

                    foreach (var item in OrderList.Items)
                    {
                        string row = item.ToString();

                        // Expect format: C001|Sandwich|2|30
                        if (!row.Contains("|"))
                            continue;

                        string[] parts = row.Split('|');

                        if (parts.Length < 4)
                            continue;

                        string customerID = parts[0].Trim();
                        string itemName = parts[1].Trim();
                        int quantity = int.Parse(parts[2].Trim());
                        decimal price = decimal.Parse(parts[3].Trim());

                        string orderID = "ORD" + DateTime.Now.Ticks.ToString().Substring(10);

                        string sql = @"INSERT INTO [Order]
                   (orderID, orderDescription, ItemPrice, Quantity, CustomerID)
                   VALUES (@id, @desc, @price, @qty, @cust)";

                        using (SqlCommand cmd = new SqlCommand(sql, conn))
                        {
                            cmd.Parameters.AddWithValue("@id", orderID);
                            cmd.Parameters.AddWithValue("@desc", itemName);
                            cmd.Parameters.AddWithValue("@price", price);
                            cmd.Parameters.AddWithValue("@qty", quantity);
                            cmd.Parameters.AddWithValue("@cust", customerID);

                            cmd.ExecuteNonQuery();
                        }
                    }

                    MessageBox.Show("Order submitted successfully!");

                    OrderList.Items.Clear();
                    lbPrice.Text = "";
                }
                catch (SqlException ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            using (SqlConnection conn = new SqlConnection(DBConfig.ConnectionString))
            {
                try
                {
                    conn.Open();

                    string sql = @"SELECT 
                           orderID AS 'Order ID',
                           orderDescription AS 'Item',
                           Quantity,
                           ItemPrice AS 'Price (R)'
                           FROM [Order]
                           WHERE CustomerID = @cust";

                    SqlCommand cmd = new SqlCommand(sql, conn);
                    cmd.Parameters.AddWithValue("@cust", loginForm.LoggedInCustomerID);

                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    DataTable dt = new DataTable();

                    da.Fill(dt);

                    // Bind to DataGridView
                    dataGridView1.DataSource = dt;
                }
                catch (SqlException ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }

        private void linklb_back_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            loginForm login = new loginForm();
            login.Show();

            this.Hide();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}

