﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace grp3PROJECT
{
    public partial class ReportForm : Form
    {
        //Declare and assign the field
        SqlCommand cmd;
        SqlDataAdapter adapter = new SqlDataAdapter();
        DataSet data = new DataSet();
        SqlDataReader reader;
        public ReportForm()
        {
            InitializeComponent();
        }

        private void ReportForm_Load(object sender, EventArgs e)
        {

        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            try
            {
                using (SqlConnection conn = new SqlConnection(DBConfig.ConnectionString))
                {
                    conn.Open();

                    cmd = new SqlCommand("UPDATE Report SET Quantity=@qty,Sales=@sales WHERE Item=@item", conn);

                    cmd.Parameters.AddWithValue("@Qty", txtQuantity.Text);
                    cmd.Parameters.AddWithValue("@item", cbItems.Text);
                    cmd.Parameters.AddWithValue("@sales", txtSales.Text);
                    cmd.ExecuteNonQuery();

                    conn.Close();
                    MessageBox.Show("Information Updated Successfully");
                }
                
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            cbItems.SelectedIndex = -1;
            txtQuantity.Text = "";
            txtSales.Text = "";
        }

        private void btnStock_Click(object sender, EventArgs e)
        {
            using (SqlConnection conn = new SqlConnection(DBConfig.ConnectionString))
            {
                conn.Open();
                lblReport.Items.Add("The following is the stock available summary report:");
                lblReport.Items.Add("---------------------------------------------------------------------------------------");
                cmd = new SqlCommand("SELECT * FROM Report", conn);
                reader = cmd.ExecuteReader();
                while (reader.Read())
                {

                    string output = reader.GetValue(0) + " Stock available: " + reader.GetValue(2);


                    lblReport.Items.Add(output);
                }

                conn.Close();
                lblReport.Items.Add("---------------------------------------------------------------------------------------");
            }
            

        }

        private void btnSales_Click(object sender, EventArgs e)
        {
            using (SqlConnection conn = new SqlConnection(DBConfig.ConnectionString))
            {
                conn.Open();
                lblReport.Items.Add("The following is the product sales' summary report:");
                lblReport.Items.Add("---------------------------------------------------------------------------------------");
                cmd = new SqlCommand("SELECT * FROM Report", conn);
                reader = cmd.ExecuteReader();
                while (reader.Read())
                {

                    string output = reader.GetValue(0) + " sales: " + reader.GetValue(1);


                    lblReport.Items.Add(output);
                }

                conn.Close();
                lblReport.Items.Add("---------------------------------------------------------------------------------------");
            }
            
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            lblReport.Items.Clear();
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            btnMaintainSupp back = new btnMaintainSupp();
            back.ShowDialog();
            this.Hide();
        }
    }
}
