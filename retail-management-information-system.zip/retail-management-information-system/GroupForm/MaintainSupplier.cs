﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace grp3PROJECT
{
    public partial class MaintainSupplier : Form
    {
        //Declare and assign the field
        SqlCommand cmd;
        SqlDataAdapter adapter = new SqlDataAdapter();
        DataSet data = new DataSet();
        public MaintainSupplier()
        {
            InitializeComponent();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            try
            {
                using (SqlConnection conn = new SqlConnection(DBConfig.ConnectionString))
                {
                    conn.Open();

                    cmd = new SqlCommand("INSERT INTO Supplier (SupplierID,Contact,Email,Name) VALUES (@id,@contact,@email,@name)", conn);

                    cmd.Parameters.AddWithValue("@id", txtAddID.Text);
                    cmd.Parameters.AddWithValue("@contact", txtAddContact.Text);
                    cmd.Parameters.AddWithValue("@email", txtAddEmail.Text);
                    cmd.Parameters.AddWithValue("@name", txtAddName.Text);
                    cmd.ExecuteNonQuery();

                    MessageBox.Show("Information added Successfully");
                    conn.Close();
                }
                
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            txtAddID.Text = "";
            txtAddContact.Text = "";
            txtAddEmail.Text = "";
            txtAddName.Text = "";
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            try
            {
                using (SqlConnection conn = new SqlConnection(DBConfig.ConnectionString))
                {
                    conn.Open();

                    cmd = new SqlCommand("UPDATE Supplier SET supplierID=@id,Contact=@contact,Email=@email WHERE Name=@name", conn);

                    cmd.Parameters.AddWithValue("@id", txtUpdateID.Text);
                    cmd.Parameters.AddWithValue("@contact", txtUpdateContact.Text);
                    cmd.Parameters.AddWithValue("@email", txtUpdateEmail.Text);
                    cmd.Parameters.AddWithValue("@name", txtUpdateName.Text);
                    cmd.ExecuteNonQuery();


                    conn.Close();
                    MessageBox.Show("Information Updated Successfully");
                }
                
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            txtUpdateID.Text = "";
            txtUpdateContact.Text = "";
            txtUpdateEmail.Text = "";
            txtUpdateName.Text = "";
        }

        private void txtDel_Click(object sender, EventArgs e)
        {
            try
            {
                using (SqlConnection conn = new SqlConnection(DBConfig.ConnectionString))
                {
                    conn.Open();

                    cmd = new SqlCommand("DELETE FROM Supplier WHERE supplierID=@id", conn);

                    cmd.Parameters.AddWithValue("@id", txtDel.Text);
                    cmd.ExecuteNonQuery();

                    MessageBox.Show("Information Deleted Successfully");
                    conn.Close();
                }
                
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            txtDel.Text = "";
        }

        private void MaintainSupplier_Load(object sender, EventArgs e)
        {

        }
    }
}
